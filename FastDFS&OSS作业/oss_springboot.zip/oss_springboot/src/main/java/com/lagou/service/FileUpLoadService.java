package com.lagou.service;

import com.aliyun.oss.OSSClient;
import com.aliyun.oss.model.OSSObject;
import com.lagou.bean.UpLoadResult;
import com.lagou.config.AliyunConfig;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.util.UUID;
@Service
public class FileUpLoadService {
    @Autowired
    private AliyunConfig aliyunConfig;
    @Autowired
    private OSSClient  ossClient;
    // 允许上传的格式
    private static final String[] IMAGE_TYPE = new String[]{".jpg", ".jpeg", ".png"};
    public UpLoadResult  upload(MultipartFile multipartFile){
        // 校验图片格式
        boolean isLegal = false;
        for (String type:IMAGE_TYPE){
            if(StringUtils.endsWithIgnoreCase(multipartFile.getOriginalFilename(),type)){
                isLegal = true;
                break;
            }
        }
        UpLoadResult upLoadResult = new UpLoadResult();
        if (!isLegal){
            upLoadResult.setStatus("必须为 jpg、png 或者 jpeg类型");
            return  upLoadResult;
        }

        // 大小检查：必须小于5M，大于5M时返回错误提示信息
        boolean size = checkFileSize(multipartFile.getSize(), 5, "M");
        System.out.println("size" + size);
        if (!size) {
            upLoadResult.setStatus("文件大小必须小于5M");
            return upLoadResult;
        }

        String fileName = multipartFile.getOriginalFilename();
        String filePath = getFilePath(fileName);
        try {
            ossClient.putObject(aliyunConfig.getBucketName(),filePath,new ByteArrayInputStream(multipartFile.getBytes()));
        } catch (IOException e) {
            e.printStackTrace();
            // 上传失败
            upLoadResult.setStatus("上传失败");
            return  upLoadResult;
        }
        upLoadResult.setStatus("上传成功");
        upLoadResult.setName(aliyunConfig.getUrlPrefix()+filePath);
        upLoadResult.setUid(filePath);
        return upLoadResult;
    }

    public UpLoadResult download(String fileName) throws IOException {
        UpLoadResult upLoadResult = new UpLoadResult();
        OSSObject ossObject = ossClient.getObject(aliyunConfig.getBucketName(), fileName);
        InputStream inputStream = ossObject.getObjectContent();
        StringBuilder objectContent = new StringBuilder();
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        while (true) {
            String line = reader.readLine();
            if (line == null)
                break;
            objectContent.append(line);
        }
        inputStream.close();
        //System.out.println("Object：" + firstKey + "的内容是：" + objectContent);
        upLoadResult.setStatus("下载文件成功");
        upLoadResult.setResponse(objectContent.toString());
        return upLoadResult;
    }

    public UpLoadResult delete(String fileName){
        UpLoadResult upLoadResult = new UpLoadResult();
        ossClient.deleteObject(aliyunConfig.getBucketName(), fileName);
        upLoadResult.setStatus("删除文件成功");
        return upLoadResult;
    }

    // 生成不重复的文件路径和文件名
    private String getFilePath(String sourceFileName) {
        DateTime dateTime = new DateTime();
        return "images/" + dateTime.toString("yyyy")
                + "/" + dateTime.toString("MM") + "/"
                + dateTime.toString("dd") + "/" + UUID.randomUUID().toString() + "." +
                StringUtils.substringAfterLast(sourceFileName, ".");
    }

    // 大小检查：必须小于5M，大于5M时返回错误提示信息
    private boolean checkFileSize(Long len, int size, String unit) {
        double fileSize = 0;
        if ("B".equals(unit.toUpperCase())) {
            fileSize = (double) len;
        } else if ("K".equals(unit.toUpperCase())) {
            fileSize = (double) len / 1024;
        } else if ("M".equals(unit.toUpperCase())) {
            fileSize = (double) len / 1048576;
        } else if ("G".equals(unit.toUpperCase())) {
            fileSize = (double) len / 1073741824;
        }
        if (fileSize > size) {
            return false;
        }
        return true;
    }
}
