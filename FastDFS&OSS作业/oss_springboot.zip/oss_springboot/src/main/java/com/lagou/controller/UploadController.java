package com.lagou.controller;

import com.lagou.bean.UpLoadResult;
import com.lagou.service.FileUpLoadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Controller
@RequestMapping("/pic")
public class UploadController {
    @Autowired
    private FileUpLoadService  fileUpLoadService;

    @PostMapping("/upload")
    @ResponseBody
    public UpLoadResult upload(@RequestParam("file") MultipartFile  multipartFile){
        return  fileUpLoadService.upload(multipartFile);
    }

    @GetMapping("/download")
    @ResponseBody
    public UpLoadResult download(@RequestParam("fileName") String fileName) throws IOException {
        return  fileUpLoadService.download(fileName);
    }

    @GetMapping("/delete")
    @ResponseBody
    public UpLoadResult delete(@RequestParam("fileName") String fileName) throws IOException {
        return  fileUpLoadService.delete(fileName);
    }
}
